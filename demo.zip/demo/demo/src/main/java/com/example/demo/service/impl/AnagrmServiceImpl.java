package com.example.demo.service.impl;

import com.example.demo.entity.AnagramRequest;
import com.example.demo.service.AnagramService;
import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class AnagrmServiceImpl implements AnagramService {

    @Override
    public boolean checkAnagram(AnagramRequest request) {
        //case sensitive
        if(request == null || request.getStr1() == null || request.getStr2() == null)
            return true;

        char[] charArray1 = request.getStr1().replaceAll("[^A-Za-z]", "").toCharArray();
        char[] charArray2 = request.getStr2().replaceAll("[^A-Za-z]", "").toCharArray();

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        return Arrays.equals(charArray1, charArray2);
    }
}
