package com.example.demo.service;

import com.example.demo.entity.AnagramRequest;

public interface AnagramService {

    boolean checkAnagram(AnagramRequest request);
}
